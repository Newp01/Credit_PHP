<!DOCTYPE html>
<html>
	<head>
		<title><?php echo TITLE; ?></title>
		<link rel = "stylesheet" type = "text/css" href = "../CSS/Style.css"></link>
	</head>
	<body>
		<div>
			<h2 id = "header">
				SOME BANK'S 
			</h2>
		
		</div>
		<div><h1>CREDIT CARD ONLINE</h1></div>