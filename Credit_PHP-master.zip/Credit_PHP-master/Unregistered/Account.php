<?php
	define("TITLE", "Account - Log In - Credit Card Online - Some Bank");//title
	include('../Header.php');//header
	include('../Nav.php');//menu
	include('../UnregContent.php');//content
	include('../Footer.php');//footer
?>

<style>#footer{ margin-top : 250px;}</style>