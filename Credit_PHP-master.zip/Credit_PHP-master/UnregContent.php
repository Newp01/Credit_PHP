<div id = "accountBody">
	<p class = "accountContent"><a id = "accountLogInButton" href = "LogIn.php">Log In/Register</a></p>
</div>