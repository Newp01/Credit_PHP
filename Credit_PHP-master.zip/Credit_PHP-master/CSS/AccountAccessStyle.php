<style>

#accountAccessContent{
	opacity: 0.7;
    filter: alpha(opacity=70);
	margin-top: 150px;
	text-align: center;
	
}

#accountAccessContentRadioChild{
	color: white;
	border: solid black 1px;
	background-color: black;
	border-radius: 4px;
	margin-right:570px; 
	margin-left:570px;
}

#accountAccessContentRadioLabel{
	margin-left: -80px;
}

#accountAccessContentRadioPassword{
	margin-left: 20px;
}

#accountAccessContentForm{
	margin-left:500px;
	margin-top: -80px;
	width: 350px;
	padding-top: 30px;
	padding-bottom: 20px;
	color: white;
	border: solid black 1px;
	background-color: black;
	border-radius: 4px;	
}

#accountAccessContentButton{
	text-decoration:none;
	background-color:#26734d;
	margin-top: 15px;
	color: white;
	padding: 7px 14px 7px 14px;
	border: solid #26734d 1px;
	border-radius: 3px
}
#accountAccessContentButton:hover {
    color: white;
	background-color:#e600e6;
	border-color: #e600e6;
}

.accountAccessContentPage{
	padding: 5px 0 5px 0;
}

.accountAccessTextBox{
	padding-left: 4px;
	width: 220px;
	height: 25px;
	appearance: none;
	box-shadow: none;
	outline: none;
	border-radius:2px;
	border: solid #3399ff 1px;
}

.accountAccessTextBox:focus{
    border-color: #ff6666;
	border-radius:4px;
	background-color: white;
}



#setPasswordContent{
	text-align: center;
	margin-top: 200px;
	color: white;
	border: solid black 1px;
	background-color: black;
	font-size: 1.2em;
}

a{
	text-decoration: none;
	color:red;
}

</style>