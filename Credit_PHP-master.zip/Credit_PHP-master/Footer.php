	
	<div id = "footer"><small>&copy;<?php echo date('Y'); ?> Group10's Some Bank</small></div>	
	</body>
</html>
