<nav>
	<a class = "menu" href = "Account.php">Account</a>
	<a class = "menu" href = "ApplyOnline.php">Apply Now</a>
	<a class = "menu" href = "TypesOfCards.php">Card Type</a>
	<a class = "menu" href = "DeactivateCard.php">Deactivate Card</a>
	<a class = "menu" href = "Lost.php">Lost Card?</a>
	<a class = "menu" href = "ContactUs.php">Contact Us</a>
</nav>
		